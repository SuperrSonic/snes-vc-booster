This is primarily a fork of 'nandloader' from noahpistilli, while technically the actual nandloader where the magic happens is produced by wiipax (https://github.com/fail0verflow/hbc/tree/master/wiipax), a PC tool that embeds the channel-compatible bootup and LZMA compression to ELF files.
However, in order to actually use this for loading official channels like Virtual Console, I use code from Taiko (https://github.com/LemonBoy/taiko) even though this works, any title that uses IOS reloading to reset will trigger a reboot or crash, i.e. N64 titles.

Using it for NES, SNES, NEOGEO, MS, GENESIS, etc. should work perfectly.

I also copied over LZ10/11 support for DOLs. While taiko seemingly works fine, it can't reliably boot later titles, has no compression on itself, and doesn't work on vWii.

One final advantage is that you can load patched DOLs with gecko codes using wstrt, the official nandloaders don't allow booting games like this.



ORIGINAL README FROM noahpistilli:

# nandloader
Cross Platform Nintendo Wii/vWii NANDLoader

## Why?
NANDLoaders come in two flavours, vWii and Wii. For the Wii Shop Channel, we wanted to have only one NANDLoader that works on both Wii and vWii for easier installation on our end. Less files on server and no need to check if the installing console is a Wii or vWii.

## How to compile
You will need `devkitppc` with the `DEVKITPRO` and `DEVKITPPC` enviornment variables set. After it is compiled, you will need to use [wiipax](https://github.com/fail0verflow/hbc/tree/master/wiipax) from the Homebrew Channel repository to fix up the ELF. Use the flag `-c dkppcchannel` and run `elf2dol` on the outputted ELF. After that, pack into your channel and it should work!

## Credits
fail0verflow's [Homebrew Channel](https://github.com/fail0verflow/hbc)
WiiPAX and the stub present in the `data` folder was sourced from them, as well as the `reloc` function.
