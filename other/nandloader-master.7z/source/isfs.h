#ifndef OSC_WIILOADER_ISFS_H
#define OSC_WIILOADER_ISFS_H

#include <ogcsys.h>

void* ISFS_GetFile(u32* size);

#endif //OSC_WIILOADER_ISFS_H
