#include <gccore.h>
#include <unistd.h>
#include <stdio.h>
#include <sdcard/wiisd_io.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include <fat.h>
#include <time.h>
#include <gccore.h>
#include <ogc/lwp_watchdog.h>

#include "stub_bin.h"
#include "isfs.h"
#include "lz77.h"

// VC load fixes
void __shutdownIos()		{ SYS_ResetSystem(SYS_SHUTDOWN, 0, 0); }
void __setTime()			{ settime(secs_to_ticks(time(NULL) - 946684800)); }

void __setupRam()
{
	//printf("\t[*] Setting bus speed\n");

//	write32(0x800000F8, 0x0E7BE2C0);
    vu32* busSpeedo = (vu32*)0x800000F8;
	*busSpeedo = 0x0E7BE2C0;

	//printf("\t[*] Setting cpu speed\n");

//	write32(0x800000FC, 0x2B73A840);
    vu32* cpuSpeedo = (vu32*)0x800000FC;
	*cpuSpeedo = 0x2B73A840;
	
	DCFlushRange((void*)0x800000F8, 0xFF);
	
	// Video
	u8 videoMode = VI_NTSC;
	videoMode = CONF_GetVideo() != CONF_VIDEO_NTSC ? VI_PAL : VI_NTSC;
	*(u32 *)0x800000CC = videoMode;
	DCFlushRange((void*)0x800000CC, sizeof(u32));
}

// Search patches
static u32 pattern_002_error[2] = {0x40820214, 0x3C608000};
static u32 patch_002_error[2] = {0x48000214, 0x3C608000};

void fix002error()
{
	//write32(0x80003188, read32(0x80003140));
	
	vu32* fixErr002_addr = (vu32*)0x80003188;
	vu32* fixErr002_fixcode = (vu32*)0x80003140;
	*fixErr002_addr = *fixErr002_fixcode;
}

u32 searchPattern(u32 address, u32 len, u32 *pattern, u32 patternLen)
{
	void *memoryBase;
	
	u32 currentAddress;
	u32 scanEndAddress;
	
	if (address >= 0x80000000 && address + len < 0x90000000)
		memoryBase = (void *)address;
	else
		return 0;

	scanEndAddress = address + len;
	
	for (currentAddress = 0; currentAddress < scanEndAddress; currentAddress++)
	{
		if (!memcmp(memoryBase + currentAddress, pattern, patternLen))
		{
			//__dprintf("Found pattern at %#x\n", (u32)(memoryBase + currentAddress));
			return (u32)(memoryBase + currentAddress);
		}
	}
	return 0;
}

void patchAddress(u32 address, u32 *patch, u32 patchLen)
{
	void *memoryBase = (void *)address;
	memcpy(memoryBase, patch, patchLen);
}

#if 0
void patch_homemenu(u8 *addr, u32 len)
{
    u8 SearchPattern[0xD] = {
        0x2C, 0x00, 0x00, 0x00, 0x41, 0x82, 0x00, 0x20, 0x38, 0x60, 0x00, 0x01, 0x48};
    u8 *addr_start = addr;
    u8 *addr_end = addr + len - sizeof(SearchPattern);
    while (addr_start <= addr_end)
    {
        if (memcmp(addr_start, SearchPattern, sizeof(SearchPattern)) == 0)
        {
            // only patch changes
			addr_start[3] = 1;

            //printf("Patched HOME Menu.\n");
            return;
        }
        addr_start += 4;
    }
}
#endif

void patch_width(u8 *addr, u32 len)
{
    u8 SearchPattern[32] = {
        0x40, 0x82, 0x00, 0x08, 0x48, 0x00, 0x00, 0x1C,
        0x28, 0x09, 0x00, 0x03, 0x40, 0x82, 0x00, 0x08,
        0x48, 0x00, 0x00, 0x10, 0x2C, 0x03, 0x00, 0x00,
        0x40, 0x82, 0x00, 0x08, 0x54, 0xA5, 0x0C, 0x3C};
    u8 *addr_start = addr;
    u8 *addr_end = addr + len - sizeof(SearchPattern);
    while (addr_start <= addr_end)
    {
        if (memcmp(addr_start, SearchPattern, sizeof(SearchPattern)) == 0)
        {
            if (addr_start[-0x70] == 0xA0 && addr_start[-0x6E] == 0x00 && addr_start[-0x6D] == 0x0A)
            {
                if (addr_start[-0x44] == 0xA0 && addr_start[-0x42] == 0x00 && addr_start[-0x41] == 0x0E)
                {
                    u8 reg_a = (addr_start[-0x6F] >> 5);
                    u8 reg_b = (addr_start[-0x43] >> 5);

                    // Patch to the framebuffer resolution
                    addr_start[-0x41] = 0x04;

                    // Center the image
                    void *offset = addr_start - 0x70;

                    u32 old_heap_ptr = *(u32 *)0x80003110;
                    *(u32 *)0x80003110 = old_heap_ptr - 0x20;
                    u32 heap_space = old_heap_ptr - 0x20;

                    u32 org_address = (addr_start[-0x70] << 24) | (addr_start[-0x6F] << 16);
                    *(u32 *)(heap_space + 0x00) = org_address | 4;
                    *(u32 *)(heap_space + 0x04) = 0x200002D0 | (reg_b << 21) | (reg_a << 16);
                    *(u32 *)(heap_space + 0x08) = 0x38000002 | (reg_a << 21);
                    *(u32 *)(heap_space + 0x0C) = 0x7C000396 | (reg_a << 21) | (reg_b << 16) | (reg_a << 11);

                    *(u32 *)offset = 0x48000000 + ((heap_space - (u32)offset) & 0x3ffffff);
                    *(u32 *)(heap_space + 0x10) = 0x48000000 + ((((u32)offset + 0x04) - (heap_space + 0x10)) & 0x3ffffff);

                    //printf("Patched resolution. Branched from 0x%x to 0x%x\n", offset, heap_space);
                    return;
                }
            }
        }
        addr_start += 4;
    }
}

static void *xfb = NULL;
static GXRModeObj *rmode = NULL;

// I/O devices
const DISC_INTERFACE *sd_slot = &__io_wiisd;
const DISC_INTERFACE *usb = &__io_usbstorage;

typedef struct _dolheader {
    u32 text_pos[7];
    u32 data_pos[11];
    u32 text_start[7];
    u32 data_start[11];
    u32 text_size[7];
    u32 data_size[11];
    u32 bss_start;
    u32 bss_size;
    u32 entry_point;
} dolheader;

typedef void (*entry_point) (void);

// How Homebrew Channel relocates the dol into mem.
static void reloc(entry_point *ep, const u8 *addr, u32 size) {
  u32 i;
  dolheader *dolfile;

  dolfile = (dolheader *) addr;

  for (i = 0; i < 7; i++) {
    if (!dolfile->text_size[i])
      continue;

    if (dolfile->text_pos[i] + dolfile->text_size[i] > size)
      return;

    memmove ((void *) dolfile->text_start[i], addr + dolfile->text_pos[i],
             dolfile->text_size[i]);

    DCFlushRange ((void *) dolfile->text_start[i], dolfile->text_size[i]);
    ICInvalidateRange ((void *) dolfile->text_start[i],
                       dolfile->text_size[i]);
  }

  for(i = 0; i < 11; i++) {
    if (!dolfile->data_size[i])
      continue;

    if (dolfile->data_pos[i] + dolfile->data_size[i] > size)
      return;

    memmove ((void*) dolfile->data_start[i], addr + dolfile->data_pos[i],
             dolfile->data_size[i]);

    DCFlushRange ((void *) dolfile->data_start[i], dolfile->data_size[i]);
  }

  *ep = (entry_point) dolfile->entry_point;
}

static int load(entry_point *ep) {
  // OSC executable will always be in content 2
  s32 fd = ES_OpenContent(1);
  if (fd < 0)
    return -1;


  u32 data_size = ES_SeekContent(fd, 0, SEEK_END);
  // TODO: Bounds on the size in TMD?
  if (data_size <= sizeof(dolheader))
    return -1;

  ES_SeekContent(fd, 0, SEEK_SET);

  s32 aligned_length = data_size;
  s32 remainder = aligned_length % 32;
  if (remainder != 0) {
    aligned_length += 32 - remainder;
  }

  void* buf = aligned_alloc(32, aligned_length);
  ES_ReadContent(fd, buf, data_size);
  ES_CloseContent(fd);
  
  // Check LZ compression type and decompress
  u8 *decData;
  u32 decDataSize = 0;
  int compressed = isLZ77compressed(buf);

  if (compressed)
  {
     decompressLZ77content(buf, data_size, &decData, decDataSize);	
     free(buf);
  }
  
  // 002 fix
  u32 error002patch = searchPattern(0x80000000, data_size, pattern_002_error, sizeof(pattern_002_error));
  if (error002patch > 0)
    patchAddress(error002patch, patch_002_error, sizeof(patch_002_error));
  fix002error();

  if (compressed)
    reloc(ep, (u8*)decData, 6*1024*1024); // 6MB limit, SA1 games are over 5MB
  else
    reloc(ep, (u8*)buf, data_size);

#if 1
  // Remove VI scaling if widescreen is set
  if(CONF_GetAspectRatio() == CONF_ASPECT_16_9) {
    patch_width((u8*)0x80002000, 2*1024*1024); //use 4 MB for better likelihood
    //patch_homemenu((u8*)0x80002000, 1*1024*1024);
  }
#endif
  
  return 0;
}

#if 0
s32 init_fat() {
  // Initialize IO
  usb->startup();
  sd_slot->startup();

  // Check if the SD Card is inserted
  bool isInserted = __io_wiisd.isInserted();

  // Try to mount the SD Card before the USB
  if (isInserted) {
    fatMountSimple("fat", sd_slot);
  } else {
    // Since the SD Card is not inserted, we will attempt to mount the USB.
    bool USB = __io_usbstorage.isInserted();
    if (USB) {
      fatMountSimple("fat", usb);
    } else {
      __io_usbstorage.shutdown();
      __io_wiisd.shutdown();
      printf("No SD Card or USB is inserted");
      sleep(5);
      return -1;
    }
  }

  return 0;
}
#endif

int main() {
  // Stub from the homebrew channel
//  memcpy((u32 *) 0x80001800, stub_bin, stub_bin_size);
//  DCFlushRange((u32 *) 0x80001800, stub_bin_size);

  VIDEO_Init();

  rmode = VIDEO_GetPreferredMode(NULL);
  xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
  console_init(xfb, 20, 20, rmode->fbWidth, rmode->xfbHeight,
               rmode->fbWidth * VI_DISPLAY_PIX_SZ);
  VIDEO_Configure(rmode);
  VIDEO_SetNextFramebuffer(xfb);
  VIDEO_SetBlack(TRUE); // was false, but shows green screen
  VIDEO_Flush();
  VIDEO_WaitVSync();
  if (rmode->viTVMode & VI_NON_INTERLACE)
    VIDEO_WaitVSync();

  // Determine if we boot from the SD Card or run the installer
//  ISFS_Initialize(); // This adds like 20 KB to the final, compressed build

#if 0
  init_fat();

  u32 size = 0;
  void* data = ISFS_GetFile(&size);
  if (data)
  {
    // Load from I/O
    // We first need to null terminate the buffer.
    char* file_path = (char*)data;
    file_path[size] = '\0';
    FILE* fp = fopen((char*)file_path, "rb");
    if (!fp)
    {
      printf("Application no longer exists. Please reinstall from the Open Shop Channel");
      sleep(5);
      return 0;
    }

    fseek(fp,0,SEEK_END);
    size_t fsize = ftell(fp);
    fseek(fp,0,SEEK_SET);

    void* buf = malloc(fsize+1);
    fread(buf, 1, fsize, fp);

    entry_point ep = 0;
    reloc(&ep, (u8*)buf, fsize);
    ep();
  }
#endif

  entry_point ep = 0;
  int ret = load(&ep);
  if (ret < 0 || ep == 0)
  {
    printf("Unable to boot game!\n");
    sleep(4);
    return 0;
  }
  
  // Allows message board playlog calculation to work
  __setTime();
  
  // Allows VC titles to start
  __setupRam();
  
  // Allows reset/power buttons to work
  __shutdownIos();

  ep();

  return 0;
}
